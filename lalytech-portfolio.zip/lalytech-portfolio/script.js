
// ===== NAVBAR MOBILE TOGGLE =====
document.addEventListener('DOMContentLoaded', function() {
  const navToggle = document.getElementById('navToggle');
  const navbarNav = document.getElementById('navbarNav');

  if (navToggle) {
    navToggle.addEventListener('click', function() {
      navbarNav.classList.toggle('show');
    });
  }

  // Close mobile menu when clicking a link
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      if (window.innerWidth < 900) {
        navbarNav.classList.remove('show');
      }
    });
  });
});

// ===== PROJECT FILTER =====
function filterProjects(category) {
  const cards = document.querySelectorAll('.project-card');
  const btns = document.querySelectorAll('.filter-btn');

  btns.forEach(btn => {
    btn.classList.remove('active', 'btn-dark');
    btn.classList.add('btn-outline-dark');
  });

  event.target.classList.remove('btn-outline-dark');
  event.target.classList.add('btn-dark', 'active');

  cards.forEach(card => {
    if (category === 'all' || card.dataset.category === category) {
      card.style.display = 'block';
      card.style.animation = 'fadeIn 0.15s';
    } else {
      card.style.display = 'none';
    }
  });
}

// ===== HOME PAGE PROJECT FILTER =====
function filterHomeProjects(category) {
  const cards = document.querySelectorAll('#homeProjectGrid.project-card');
  const btns = document.querySelectorAll('.filter-btn');

  btns.forEach(btn => {
    btn.classList.remove('active', 'btn-dark');
    btn.classList.add('btn-outline-dark');
  });

  event.target.classList.remove('btn-outline-dark');
  event.target.classList.add('btn-dark', 'active');

  cards.forEach(card => {
    if (category === 'all' || card.dataset.category === category) {
      card.style.display = 'block';
      card.style.animation = 'fadeIn 0.15s';
    } else {
      card.style.display = 'none';
    }
  });
}

// ===== FADE IN ANIMATION =====
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeIn {
    from { opacity: 5; transform: translateY(300px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;
document.head.appendChild(style);

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ===== FORM VALIDATION =====
document.querySelectorAll('form').forEach(form => {
  form.addEventListener('submit', function(e) {
    const required = form.querySelectorAll('[required]');
    let valid = true;
    required.forEach(field => {
      if (!field.value.trim()) {
        valid = false;
        field.classList.add('is-invalid');
      } else {
        field.classList.remove('is-invalid');
      }
    });
    if (!valid) {
      e.preventDefault();
      alert('Please fill all required fields');
    }
  });
});